"""
pages/visual_storytelling.py
────────────────────────────
Chapter 5 — Visual Storytelling
Animated charts, interactive choropleth map, timeline heatmaps.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

LAYOUT = dict(
    paper_bgcolor="#0a0e1a", plot_bgcolor="#111827",
    font=dict(color="#f1f5f9", family="Source Sans 3"),
    margin=dict(l=10, r=10, t=60, b=10),
)


def render(df):
    st.markdown("""
    <div class='section-tag'>Chapter 05</div>
    <div class='section-title'>Seeing the Pandemic</div>
    <p class='narrative-text'>
    Data becomes a story when it moves. This chapter deploys animated charts, global maps,
    and heatmaps to give the pandemic a visual shape — so that patterns invisible in tables
    leap out of the screen.
    </p>
    """, unsafe_allow_html=True)

    latest = df.sort_values("date").groupby("country").last().reset_index()
    latest["cases_per_million"]    = (latest["total_cases"] / latest["population"] * 1e6).round(0)
    latest["deaths_per_million"]   = (latest["total_deaths"] / latest["population"] * 1e6).round(1)
    latest["vaccination_rate_pct"] = (latest["people_fully_vaccinated"] / latest["population"] * 100).round(1)
    latest["mortality_rate"]       = (latest["total_deaths"] / latest["total_cases"].replace(0, np.nan) * 100).round(2)

    # ── 1. Animated Bar Chart Race (monthly snapshots) ────────────────────────
    st.markdown("### 🎬 Animated Case Race — Top 10 Countries")
    st.markdown("""
    <p class='narrative-text' style='margin-top:0;'>
    Watch how the ranking of hardest-hit nations evolved month by month.
    Press Play to start the animation.
    </p>
    """, unsafe_allow_html=True)

    # Monthly snapshot — last day of each month
    df_monthly = (
        df.groupby(["country", pd.Grouper(key="date", freq="ME")])
          .last()
          .reset_index()
    )
    # For each month keep only top 10 by total cases
    frames_data = []
    months = sorted(df_monthly["date"].unique())
    for month in months:
        month_df = df_monthly[df_monthly["date"] == month].nlargest(10, "total_cases")
        month_df = month_df.sort_values("total_cases")
        month_df["month_label"] = pd.Timestamp(month).strftime("%b %Y")
        frames_data.append(month_df)
    race_df = pd.concat(frames_data, ignore_index=True)

    fig_race = px.bar(
        race_df,
        x="total_cases",
        y="country",
        animation_frame="month_label",
        color="continent",
        orientation="h",
        range_x=[0, race_df["total_cases"].max() * 1.1],
        color_discrete_sequence=px.colors.qualitative.Set2,
        text="total_cases",
    )
    fig_race.update_traces(texttemplate="%{text:,.0f}", textposition="outside")
    fig_race.update_layout(
        **LAYOUT, height=500,
        xaxis_title="Total Cases",
        title=dict(text="Monthly Ranking: Most-Infected Countries", font=dict(size=15)),
        updatemenus=[dict(
            type="buttons", showactive=False,
            y=1.05, x=0, xanchor="left",
            buttons=[
                dict(label="▶ Play",  method="animate",
                     args=[None, dict(frame=dict(duration=300, redraw=True), fromcurrent=True)]),
                dict(label="⏸ Pause", method="animate",
                     args=[[None], dict(frame=dict(duration=0), mode="immediate")]),
            ],
            bgcolor="#1a2235", bordercolor="rgba(255,255,255,0.1)",
            font=dict(color="#f1f5f9"),
        )],
    )
    st.plotly_chart(fig_race, use_container_width=True)

    # ── 2. Choropleth World Map ───────────────────────────────────────────────
    st.markdown("### 🗺️ Interactive World Map")
    map_metric = st.selectbox(
        "Map metric:",
        ["Cases per Million", "Deaths per Million", "Vaccination Rate (%)", "Mortality Rate (%)"],
    )
    metric_col_map = {
        "Cases per Million":    ("cases_per_million",    "Reds"),
        "Deaths per Million":   ("deaths_per_million",   "OrRd"),
        "Vaccination Rate (%)": ("vaccination_rate_pct", "Greens"),
        "Mortality Rate (%)":   ("mortality_rate",       "YlOrRd"),
    }
    col_name, cscale = metric_col_map[map_metric]

    fig_map = px.choropleth(
        latest,
        locations="iso_code",
        color=col_name,
        hover_name="country",
        hover_data={col_name: ":.2f"},
        color_continuous_scale=cscale,
        projection="natural earth",
    )
    fig_map.update_layout(
        **LAYOUT, height=480,
        geo=dict(
            bgcolor="#0a0e1a",
            landcolor="#1a2235",
            oceancolor="#0a0e1a",
            lakecolor="#0a0e1a",
            showocean=True, showlakes=True, showland=True,
            countrycolor="rgba(255,255,255,0.12)",
            framecolor="rgba(255,255,255,0.05)",
        ),
        coloraxis_colorbar=dict(tickfont=dict(color="#94a3b8"), title=dict(font=dict(color="#94a3b8"))),
        title=dict(text=f"World Map — {map_metric}", font=dict(size=15)),
    )
    st.plotly_chart(fig_map, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>🗺️ Insight</div>
      <p>Toggle between metrics to see how the map changes dramatically. The <em>cases per million</em>
         map shows a high-income / Europe-centric story. The <em>vaccination rate</em> map flips
         to show the same wealthier nations leading — while sub-Saharan Africa lags across both
         maps, pointing to a deeply unequal global health landscape.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── 3. Heatmap — Monthly Cases by Country ────────────────────────────────
    st.markdown("### 🌡️ Heatmap — Monthly Case Intensity")

    df_heat = (
        df.groupby(["country", pd.Grouper(key="date", freq="ME")])["new_cases"]
          .sum().reset_index()
    )
    df_heat["month_label"] = df_heat["date"].dt.strftime("%b %Y")
    pivot = df_heat.pivot(index="country", columns="month_label", values="new_cases")

    # Reorder months chronologically
    all_months = df_heat.sort_values("date")["month_label"].unique()
    pivot = pivot.reindex(columns=all_months).fillna(0)
    # Sort countries by total cases
    pivot = pivot.loc[pivot.sum(axis=1).sort_values(ascending=False).index]

    fig_heat = go.Figure(data=go.Heatmap(
        z=np.log1p(pivot.values),
        x=pivot.columns,
        y=pivot.index,
        colorscale="YlOrRd",
        hovertemplate="<b>%{y}</b><br>%{x}<br>Log(Cases+1): %{z:.2f}<extra></extra>",
        colorbar=dict(title="log(cases+1)", tickfont=dict(color="#94a3b8")),
    ))
    fig_heat.update_layout(
        **LAYOUT, height=600,
        xaxis=dict(tickangle=-45, tickfont=dict(size=9), gridcolor="rgba(0,0,0,0)"),
        yaxis=dict(tickfont=dict(size=10), gridcolor="rgba(0,0,0,0)"),
        title=dict(text="Monthly Case Intensity Heatmap (log scale) — All Countries", font=dict(size=15)),
    )
    st.plotly_chart(fig_heat, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>🌡️ Insight</div>
      <p>The heatmap reveals wave synchrony: most countries light up simultaneously during
         major variant surges. India's row blazes during the Delta wave in May 2021 — brighter
         than any other cell in the chart. The Omicron columns (Nov 2021–Feb 2022) show broad
         simultaneous ignition across virtually every country, the most globally synchronised
         wave of the pandemic.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── 4. Animated Scatter — Cases vs Deaths (monthly) ──────────────────────
    st.markdown("### 🔮 Animated Scatter — Cases vs Deaths Over Time")

    df_scatter = (
        df.groupby(["country", "continent", pd.Grouper(key="date", freq="ME")])
          .agg(total_cases=("total_cases","last"), total_deaths=("total_deaths","last"),
               population=("population","first"))
          .reset_index()
    )
    df_scatter["month_label"]      = df_scatter["date"].dt.strftime("%b %Y")
    df_scatter["cases_per_million"] = df_scatter["total_cases"] / df_scatter["population"] * 1e6
    df_scatter["deaths_per_million"]= df_scatter["total_deaths"] / df_scatter["population"] * 1e6

    fig_scat = px.scatter(
        df_scatter,
        x="cases_per_million",
        y="deaths_per_million",
        animation_frame="month_label",
        animation_group="country",
        size="total_cases",
        color="continent",
        hover_name="country",
        log_x=True, log_y=True,
        size_max=55,
        color_discrete_sequence=px.colors.qualitative.Set2,
        range_x=[1, df_scatter["cases_per_million"].max() * 2],
        range_y=[0.1, df_scatter["deaths_per_million"].max() * 2],
    )
    fig_scat.update_layout(
        **LAYOUT, height=520,
        xaxis_title="Cases per Million (log)",
        yaxis_title="Deaths per Million (log)",
        title=dict(text="Cases vs Deaths per Million — Animated by Month", font=dict(size=15)),
        updatemenus=[dict(
            type="buttons", showactive=False,
            y=1.05, x=0, xanchor="left",
            buttons=[
                dict(label="▶ Play",  method="animate",
                     args=[None, dict(frame=dict(duration=250, redraw=True), fromcurrent=True)]),
                dict(label="⏸ Pause", method="animate",
                     args=[[None], dict(frame=dict(duration=0), mode="immediate")]),
            ],
            bgcolor="#1a2235", bordercolor="rgba(255,255,255,0.1)",
            font=dict(color="#f1f5f9"),
        )],
    )
    st.plotly_chart(fig_scat, use_container_width=True)

    # ── 5. Vaccination Timeline Gantt-style ───────────────────────────────────
    st.markdown("### 📅 Vaccination 70% Milestone Timeline")

    milestones = []
    for country in df["country"].unique():
        cdf = df[df["country"] == country].copy()
        pop = cdf["population"].iloc[0]
        cdf["vax_pct"] = cdf["people_fully_vaccinated"] / pop * 100
        hit = cdf[cdf["vax_pct"] >= 70]["date"]
        if not hit.empty:
            milestones.append({"country": country, "date_reached": hit.iloc[0]})

    if milestones:
        ms_df = pd.DataFrame(milestones).sort_values("date_reached")
        fig_ms = go.Figure(go.Bar(
            x=ms_df["date_reached"],
            y=ms_df["country"],
            orientation="h",
            marker=dict(
                color=[(d - pd.Timestamp("2021-01-01")).days for d in ms_df["date_reached"]],
                colorscale=[[0, "#2a9d8f"], [1, "#e63946"]],
                showscale=True,
                colorbar=dict(title="Days after<br>Jan 2021", tickfont=dict(color="#94a3b8")),
            ),
        ))
        fig_ms.update_layout(
            **LAYOUT, height=450,
            xaxis_title="Date 70% Full Vaccination Achieved",
            title=dict(text="When Did Each Country Reach 70% Full Vaccination?", font=dict(size=15)),
        )
        st.plotly_chart(fig_ms, use_container_width=True)
    else:
        st.info("Not all countries reached 70% — reflecting real-world vaccine equity gaps.")

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>📅 Insight</div>
      <p>The vaccination timeline tells a story of stark global inequality. While some nations
         reached the 70% milestone within the first 12 months of rollout, others have yet to
         approach it years later. The colour gradient — green for early, red for late — maps
         directly onto global wealth and health infrastructure divides.</p>
    </div>
    """, unsafe_allow_html=True)

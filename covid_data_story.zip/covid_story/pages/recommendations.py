"""
pages/recommendations.py
────────────────────────
Chapter 7 — Recommendations & Conclusion
Policy recommendations, lessons learned, and closing narrative.
"""

import streamlit as st
import plotly.graph_objects as go
import pandas as pd
import numpy as np


LAYOUT = dict(
    paper_bgcolor="#0a0e1a", plot_bgcolor="#111827",
    font=dict(color="#f1f5f9", family="Source Sans 3"),
    margin=dict(l=10, r=10, t=50, b=10),
)


def render(df):
    st.markdown("""
    <div class='section-tag'>Chapter 07</div>
    <div class='section-title'>Lessons for the Next Crisis</div>
    <p class='narrative-text'>
    Data without action is just history. The COVID-19 pandemic generated an
    unprecedented volume of evidence about what works, what doesn't, and what
    we must build before the next crisis arrives. These recommendations are drawn
    directly from the patterns revealed in this data story.
    </p>
    """, unsafe_allow_html=True)

    # ── Recommendation Cards ──────────────────────────────────────────────────
    recommendations = [
        {
            "num": "01",
            "color": "#e63946",
            "title": "Build Global Vaccine Equity Infrastructure",
            "body": (
                "The vaccination timeline analysis reveals a persistent and life-costing gap "
                "between wealthy and lower-income nations. Pre-positioned cold-chain logistics, "
                "COVAX-style pre-purchase agreements with mandatory execution clauses, and "
                "technology transfer agreements for mRNA manufacturing should be codified in "
                "international law — not left to goodwill."
            ),
            "stat": "Nigeria reached only ~15% vaccination vs Australia's 85%",
        },
        {
            "num": "02",
            "color": "#f4a261",
            "title": "Invest Heavily in Pandemic Surveillance",
            "body": (
                "Africa's under-reporting finding is a warning. Without universal testing and "
                "surveillance capacity, the world is flying blind in the early and most critical "
                "phases of an outbreak. Every nation needs a minimum genomic sequencing and "
                "epidemiological reporting infrastructure, with WHO-level enforcement."
            ),
            "stat": "Africa's true infection rate was likely 10× reported figures",
        },
        {
            "num": "03",
            "color": "#2a9d8f",
            "title": "Maintain mRNA Platform Readiness",
            "body": (
                "The development of COVID-19 vaccines in under 12 months was only possible "
                "because decades of prior mRNA research had already been done. Governments "
                "must sustain public funding for platform technologies even in inter-pandemic "
                "periods — treating them as national security infrastructure."
            ),
            "stat": "mRNA vaccines: 12 months vs typical 10–15 years",
        },
        {
            "num": "04",
            "color": "#457b9d",
            "title": "Pre-Agree on International Data Sharing",
            "body": (
                "Wave synchrony analysis shows that variants spread globally within weeks. "
                "Early detection in one nation benefits all nations. A binding international "
                "data-sharing agreement — with legal protections for reporting nations — "
                "would compress the detection-to-response timeline from months to days."
            ),
            "stat": "Omicron spread to 50+ countries within 2 weeks of detection",
        },
        {
            "num": "05",
            "color": "#e63946",
            "title": "Expand ICU and Healthcare Surge Capacity",
            "body": (
                "The correlation between healthcare system capacity and mortality rates is "
                "unambiguous. Pandemic preparedness plans must include pre-funded surge capacity "
                "protocols: ventilator stockpiles, trained reserve medical staff, and "
                "hospital surge plans that do not require ad hoc improvisation under pressure."
            ),
            "stat": "CFR in high-capacity systems was ~30% lower vs low-capacity",
        },
        {
            "num": "06",
            "color": "#f4a261",
            "title": "Combat Misinformation as a Public Health Crisis",
            "body": (
                "Vaccine hesitancy driven by misinformation directly contributed to preventable "
                "deaths and prolonged the pandemic. Governments and platforms must treat "
                "health misinformation with the same urgency as the pathogen itself — "
                "through proactive communication, trusted messenger networks, and platform accountability."
            ),
            "stat": "Hesitancy delayed herd immunity by 6–18 months in several nations",
        },
    ]

    for rec in recommendations:
        st.markdown(f"""
        <div style='background:#1a2235; border:1px solid rgba(255,255,255,0.08);
                    border-left: 4px solid {rec["color"]};
                    border-radius: 0 10px 10px 0; padding:1.4rem 1.6rem; margin-bottom:1.2rem;'>
          <div style='display:flex; gap:1.2rem; align-items:flex-start;'>
            <div style='font-family:monospace; font-size:1.8rem; font-weight:700;
                        color:{rec["color"]}; opacity:0.4; flex-shrink:0; line-height:1;'>
              {rec["num"]}
            </div>
            <div>
              <div style='font-size:1.05rem; font-weight:600; color:#f1f5f9; margin-bottom:0.5rem;'>
                {rec["title"]}
              </div>
              <div style='font-size:0.9rem; color:#94a3b8; line-height:1.75; margin-bottom:0.8rem;'>
                {rec["body"]}
              </div>
              <div style='font-family:monospace; font-size:0.78rem; color:{rec["color"]};
                          background:rgba(255,255,255,0.04); padding:0.3rem 0.6rem; border-radius:4px;
                          display:inline-block;'>
                📊 {rec["stat"]}
              </div>
            </div>
          </div>
        </div>
        """, unsafe_allow_html=True)

    # ── Preparedness Radar Chart ──────────────────────────────────────────────
    st.markdown("### 🕸️ Ideal Pandemic Preparedness Profile")
    st.markdown("""
    <p class='narrative-text' style='margin-top:0;'>
    Based on the findings, an idealised pandemic-ready nation would score highly across
    all dimensions below. The gap between the "current global average" and the ideal
    represents the work still to be done.
    </p>
    """, unsafe_allow_html=True)

    categories = [
        "Surveillance &\nReporting", "Vaccine\nCapacity",
        "Healthcare\nSurge Capacity", "International\nCooperation",
        "Misinformation\nManagement", "Equity &\nAccess",
    ]
    ideal_scores   = [9, 9, 8, 9, 8, 9]
    current_scores = [5, 6, 5, 4, 3, 4]

    fig_radar = go.Figure()
    for name, values, color, fill in [
        ("Ideal",          ideal_scores,   "#2a9d8f", "rgba(42,157,143,0.15)"),
        ("Global Average", current_scores, "#e63946", "rgba(230,57,70,0.1)"),
    ]:
        vals = values + [values[0]]
        cats = categories + [categories[0]]
        fig_radar.add_trace(go.Scatterpolar(
            r=vals, theta=cats, name=name,
            line=dict(color=color, width=2.5),
            fill="toself", fillcolor=fill,
        ))
    fig_radar.update_layout(
        **LAYOUT, height=450,
        polar=dict(
            bgcolor="#111827",
            radialaxis=dict(visible=True, range=[0,10], tickfont=dict(size=9, color="#475569"),
                            gridcolor="rgba(255,255,255,0.08)"),
            angularaxis=dict(tickfont=dict(size=10, color="#94a3b8"),
                             gridcolor="rgba(255,255,255,0.08)"),
        ),
        legend=dict(bgcolor="rgba(0,0,0,0)"),
        title=dict(text="Pandemic Preparedness — Ideal vs Estimated Global Average", font=dict(size=14)),
    )
    st.plotly_chart(fig_radar, use_container_width=True)

    # ── Closing Narrative ────────────────────────────────────────────────────
    st.markdown("<div class='chapter-divider'><div class='line'></div><div class='chapter-num'>CONCLUSION</div><div class='line'></div></div>", unsafe_allow_html=True)

    st.markdown("""
    <div class='hero-title' style='font-size:2rem;'>The Story the Data Tells</div>
    <p class='narrative-text'>
    COVID-19 was not just a health crisis. It was a mirror — reflecting the inequalities,
    fragilities, and latent capacities of every society it touched. The data shows us a world
    that responded with remarkable scientific speed and yet stumbled on equity, cooperation,
    and trust. Nations with stronger institutions, more equitable healthcare access, and
    faster vaccine rollouts fared measurably better on every metric.
    </p>
    <p class='narrative-text'>
    The pandemic is not over — SARS-CoV-2 continues to evolve and circulate. But the acute
    emergency has passed, leaving behind a body of evidence richer than any we have had
    from a previous outbreak. The question is whether the world will act on it.
    </p>
    <p class='narrative-text'>
    Data tells us what happened. Decisions determine what happens next.
    </p>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class='insight-box' style='border-left-color:#2a9d8f;'>
      <div class='insight-label' style='color:#2a9d8f;'>🌍 Closing Thought</div>
      <p>The most powerful pattern in this entire dataset is not a number —
         it is the shape of the vaccination curve. In every country where it climbed steeply,
         the death curve bent downward. That relationship is the data's clearest message:
         collective action against shared threats works. It worked in 2021. It can work again.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Final summary metrics ────────────────────────────────────────────────
    st.markdown("### 📊 Story in Numbers")
    latest = df.sort_values("date").groupby("country").last().reset_index()
    total_cases     = int(latest["total_cases"].sum())
    total_deaths    = int(latest["total_deaths"].sum())
    total_recovered = int(latest["total_recovered"].sum())
    total_vax       = int(latest["people_fully_vaccinated"].sum())
    avg_cfr         = (latest["total_deaths"].sum() / latest["total_cases"].sum() * 100)

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total Cases Tracked",     f"{total_cases/1e6:.1f}M")
    c2.metric("Total Deaths",            f"{total_deaths/1e6:.2f}M")
    c3.metric("Total Recovered",         f"{total_recovered/1e6:.1f}M")
    c4.metric("Fully Vaccinated",        f"{total_vax/1e9:.2f}B")
    c5.metric("Final Global CFR",        f"{avg_cfr:.2f}%")

    st.markdown("""
    <br><br>
    <div style='text-align:center; font-family:"JetBrains Mono",monospace; font-size:0.72rem;
                color:#475569; letter-spacing:0.1em;'>
      COVID-19: A DATA STORY &nbsp;·&nbsp; JAN 2020 — DEC 2023 &nbsp;·&nbsp; 20 COUNTRIES
    </div>
    """, unsafe_allow_html=True)

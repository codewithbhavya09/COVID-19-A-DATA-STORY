"""
pages/global_impact.py
──────────────────────
Chapter 3 — Global Impact Analysis
Cases over time, deaths over time, recovery trends, wave analysis.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

COLORS  = dict(cases="#f4a261", deaths="#e63946", recovered="#2a9d8f", active="#457b9d")
LAYOUT  = dict(
    paper_bgcolor="#0a0e1a", plot_bgcolor="#111827",
    font=dict(color="#f1f5f9", family="Source Sans 3"),
    xaxis=dict(gridcolor="rgba(255,255,255,0.04)", linecolor="rgba(255,255,255,0.1)",
               showgrid=True),
    yaxis=dict(gridcolor="rgba(255,255,255,0.04)", linecolor="rgba(255,255,255,0.1)",
               showgrid=True),
    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(255,255,255,0.1)", borderwidth=1),
    hovermode="x unified",
    margin=dict(l=10, r=10, t=50, b=10),
)


def render(df):
    st.markdown("""
    <div class='section-tag'>Chapter 03</div>
    <div class='section-title'>The Global Toll</div>
    <p class='narrative-text'>
    Numbers on a page rarely convey the weight of a pandemic. But when we chart them across
    time — watching the waves rise and fall, the death curves follow with their grim lag,
    and the green line of recovery slowly climb — the human story emerges from the data.
    This chapter tells that story globally.
    </p>
    """, unsafe_allow_html=True)

    # ── Global daily aggregates ───────────────────────────────────────────────
    global_daily = (
        df.groupby("date")
          .agg(
              total_cases  = ("total_cases",  "sum"),
              new_cases    = ("new_cases",    "sum"),
              total_deaths = ("total_deaths", "sum"),
              new_deaths   = ("new_deaths",   "sum"),
              total_recovered = ("total_recovered", "sum"),
              active_cases = ("active_cases", "sum"),
          )
          .reset_index()
    )
    # Smooth daily new cases with 7-day rolling average
    global_daily["new_cases_7d"]  = global_daily["new_cases"].rolling(7).mean()
    global_daily["new_deaths_7d"] = global_daily["new_deaths"].rolling(7).mean()

    # ── Section 1: Cumulative Cases ──────────────────────────────────────────
    st.markdown("### 📈 Cumulative Cases Over Time")

    fig1 = go.Figure()
    fig1.add_trace(go.Scatter(
        x=global_daily["date"], y=global_daily["total_cases"],
        name="Total Cases", mode="lines",
        line=dict(color=COLORS["cases"], width=2.5),
        fill="tozeroy", fillcolor="rgba(244,162,97,0.08)",
    ))
    fig1.add_trace(go.Scatter(
        x=global_daily["date"], y=global_daily["total_recovered"],
        name="Total Recovered", mode="lines",
        line=dict(color=COLORS["recovered"], width=2),
        fill="tozeroy", fillcolor="rgba(42,157,143,0.08)",
    ))
    fig1.add_trace(go.Scatter(
        x=global_daily["date"], y=global_daily["total_deaths"],
        name="Total Deaths", mode="lines",
        line=dict(color=COLORS["deaths"], width=2),
        fill="tozeroy", fillcolor="rgba(230,57,70,0.08)",
    ))

    # Annotate wave peaks
    wave_annotations = [
        ("2020-07-01", "Wave 1"),
        ("2020-12-01", "Wave 2"),
        ("2021-05-15", "Delta"),
        ("2022-01-20", "Omicron"),
    ]
    for date_str, label in wave_annotations:
        fig1.add_vline(
            x=date_str, line_dash="dot",
            line_color="rgba(255,255,255,0.15)", line_width=1,
            annotation_text=label,
            annotation_font=dict(size=10, color="#94a3b8"),
            annotation_position="top",
        )

    fig1.update_layout(**LAYOUT, height=420,
                       yaxis_title="People",
                       title=dict(text="Global Cumulative Cases, Recoveries & Deaths", font=dict(size=15)))
    st.plotly_chart(fig1, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>📈 Insight</div>
      <p>The gap between total cases and total deaths remains narrow but persistent, illustrating
         the pandemic's lethality at scale. The recovery line follows cases with a ~3-week lag —
         the typical resolution time for a COVID-19 infection. Notice how the gap between
         cases and recoveries widens during Omicron: a sign of the sheer volume of infections.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Section 2: Daily New Cases (wave chart) ──────────────────────────────
    st.markdown("### 🌊 Daily New Cases — The Six Waves")

    fig2 = go.Figure()
    fig2.add_trace(go.Bar(
        x=global_daily["date"], y=global_daily["new_cases"],
        name="Daily Cases", marker_color="rgba(244,162,97,0.3)",
    ))
    fig2.add_trace(go.Scatter(
        x=global_daily["date"], y=global_daily["new_cases_7d"],
        name="7-Day Average", mode="lines",
        line=dict(color=COLORS["cases"], width=2.5),
    ))

    fig2.update_layout(**LAYOUT, height=380,
                       barmode="overlay",
                       yaxis_title="Daily New Cases",
                       title=dict(text="Daily New Cases with 7-Day Rolling Average", font=dict(size=15)))
    st.plotly_chart(fig2, use_container_width=True)

    # ── Section 3: Deaths over time ──────────────────────────────────────────
    st.markdown("### 💀 Deaths Over Time")

    fig3 = go.Figure()
    fig3.add_trace(go.Bar(
        x=global_daily["date"], y=global_daily["new_deaths"],
        name="Daily Deaths", marker_color="rgba(230,57,70,0.3)",
    ))
    fig3.add_trace(go.Scatter(
        x=global_daily["date"], y=global_daily["new_deaths_7d"],
        name="7-Day Avg Deaths", mode="lines",
        line=dict(color=COLORS["deaths"], width=2.5),
    ))

    fig3.update_layout(**LAYOUT, height=360, barmode="overlay",
                       yaxis_title="Daily Deaths",
                       title=dict(text="Daily Deaths with 7-Day Rolling Average", font=dict(size=15)))
    st.plotly_chart(fig3, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>💀 Insight</div>
      <p>Deaths peaked during Wave 2 (Winter 2020-21) and the Delta wave — before vaccines had
         reached critical mass. Despite Omicron driving far more infections than any previous wave,
         daily deaths were significantly lower, reflecting vaccine protection against severe disease.
         This divergence between cases and deaths is one of the most powerful signals in the entire dataset.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Section 4: Active Cases (pandemic burden) ────────────────────────────
    st.markdown("### 🏥 Active Cases — Measuring Healthcare Burden")

    fig4 = go.Figure()
    fig4.add_trace(go.Scatter(
        x=global_daily["date"], y=global_daily["active_cases"],
        name="Active Cases", mode="lines",
        line=dict(color=COLORS["active"], width=2.5),
        fill="tozeroy", fillcolor="rgba(69,123,157,0.12)",
    ))
    fig4.update_layout(**LAYOUT, height=360,
                       yaxis_title="Active Cases (global)",
                       title=dict(text="Global Active Cases Over Time", font=dict(size=15)))
    st.plotly_chart(fig4, use_container_width=True)

    # ── Section 5: Continent-level breakdown ────────────────────────────────
    st.markdown("### 🌐 Cases by Continent")

    cont_daily = (
        df.groupby(["date", "continent"])["new_cases"]
          .sum().reset_index()
    )
    fig5 = px.area(
        cont_daily, x="date", y="new_cases", color="continent",
        color_discrete_sequence=px.colors.qualitative.Set2,
    )
    fig5.update_layout(**LAYOUT, height=400,
                       yaxis_title="Daily New Cases",
                       title=dict(text="Daily Cases by Continent (Stacked)", font=dict(size=15)))
    st.plotly_chart(fig5, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>🌐 Insight</div>
      <p>Europe and North America dominated early waves, but Asia's contribution surged massively
         during Omicron — driven by India's enormous population finally experiencing its largest
         wave. Africa's reported share remains small throughout, likely reflecting severe
         under-testing rather than true under-infection — a critical data quality caveat.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Year-over-year comparison ─────────────────────────────────────────────
    st.markdown("### 📅 Year-Over-Year Total Cases")
    df["year"] = df["date"].dt.year
    yearly = (df.groupby(["year", "country"])["new_cases"].sum()
                .groupby("year").sum().reset_index())
    yearly.columns = ["Year", "Total New Cases"]

    fig6 = go.Figure(go.Bar(
        x=yearly["Year"].astype(str),
        y=yearly["Total New Cases"],
        marker=dict(
            color=yearly["Total New Cases"],
            colorscale=[[0,"#457b9d"],[0.5,"#f4a261"],[1,"#e63946"]],
            showscale=False,
        ),
        text=[f"{v/1e6:.1f}M" for v in yearly["Total New Cases"]],
        textposition="outside",
        textfont=dict(color="#f1f5f9"),
    ))
    fig6.update_layout(**LAYOUT, height=350,
                       yaxis_title="Total New Cases (annual)",
                       title=dict(text="Annual Global Case Count", font=dict(size=15)))
    st.plotly_chart(fig6, use_container_width=True)

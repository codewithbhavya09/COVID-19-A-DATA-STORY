# pages/__init__.py
from pages import (
    introduction,
    exploration,
    global_impact,
    country_comparison,
    visual_storytelling,
    key_findings,
    recommendations,
)

__all__ = [
    "introduction", "exploration", "global_impact",
    "country_comparison", "visual_storytelling",
    "key_findings", "recommendations",
]

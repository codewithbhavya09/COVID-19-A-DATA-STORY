"""
pages/country_comparison.py
───────────────────────────
Chapter 4 — Country Comparison
Top affected countries, vaccination analysis, mortality rate comparison.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

LAYOUT = dict(
    paper_bgcolor="#0a0e1a", plot_bgcolor="#111827",
    font=dict(color="#f1f5f9", family="Source Sans 3"),
    xaxis=dict(gridcolor="rgba(255,255,255,0.04)", linecolor="rgba(255,255,255,0.1)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.04)", linecolor="rgba(255,255,255,0.1)"),
    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(255,255,255,0.1)", borderwidth=1),
    margin=dict(l=10, r=10, t=50, b=10),
    hovermode="closest",
)


def render(df):
    st.markdown("""
    <div class='section-tag'>Chapter 04</div>
    <div class='section-title'>Nations in the Storm</div>
    <p class='narrative-text'>
    Pandemics do not strike equally. A country's outcomes were shaped by its population density,
    healthcare capacity, political response, and — eventually — how fast it vaccinated.
    This chapter places nations side-by-side to reveal the stark differences in their
    COVID-19 journeys.
    </p>
    """, unsafe_allow_html=True)

    # Latest snapshot per country
    latest = df.sort_values("date").groupby("country").last().reset_index()
    latest["mortality_rate"]       = (latest["total_deaths"] / latest["total_cases"].replace(0, np.nan) * 100).round(2)
    latest["vaccination_rate_pct"] = (latest["people_fully_vaccinated"] / latest["population"] * 100).round(1)
    latest["cases_per_million"]    = (latest["total_cases"] / latest["population"] * 1e6).round(0)
    latest["deaths_per_million"]   = (latest["total_deaths"] / latest["population"] * 1e6).round(1)

    # ── Top 10 by Total Cases ─────────────────────────────────────────────────
    st.markdown("### 🏆 Top 10 Countries — Total Cases")

    top10_cases = latest.nlargest(10, "total_cases").sort_values("total_cases")
    fig1 = go.Figure(go.Bar(
        x=top10_cases["total_cases"],
        y=top10_cases["country"],
        orientation="h",
        marker=dict(
            color=top10_cases["total_cases"],
            colorscale=[[0, "#457b9d"], [1, "#e63946"]],
            showscale=False,
        ),
        text=[f"{v/1e6:.1f}M" for v in top10_cases["total_cases"]],
        textposition="outside",
        textfont=dict(color="#f1f5f9"),
    ))
    fig1.update_layout(**LAYOUT, height=400,
                       xaxis_title="Total Cases",
                       title=dict(text="Top 10 Countries by Cumulative Case Count", font=dict(size=15)))
    st.plotly_chart(fig1, use_container_width=True)

    # ── Top 10 by Cases Per Million ───────────────────────────────────────────
    st.markdown("### 📊 Cases Per Million — Who Really Suffered Most?")
    st.markdown("""
    <p class='narrative-text' style='margin-top:0;'>
    Raw case counts favour large nations. To compare fairly, we normalise by population.
    </p>
    """, unsafe_allow_html=True)

    top10_cpm = latest.nlargest(10, "cases_per_million").sort_values("cases_per_million")
    fig2 = go.Figure(go.Bar(
        x=top10_cpm["cases_per_million"],
        y=top10_cpm["country"],
        orientation="h",
        marker=dict(
            color=top10_cpm["cases_per_million"],
            colorscale=[[0, "#2a9d8f"], [1, "#f4a261"]],
            showscale=False,
        ),
        text=[f"{int(v):,}" for v in top10_cpm["cases_per_million"]],
        textposition="outside",
        textfont=dict(color="#f1f5f9"),
    ))
    fig2.update_layout(**LAYOUT, height=400,
                       xaxis_title="Cases per Million Population",
                       title=dict(text="Cases Per Million — Population-Adjusted Burden", font=dict(size=15)))
    st.plotly_chart(fig2, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>📊 Insight</div>
      <p>When adjusted for population, the ranking shifts significantly. Smaller nations with
         robust reporting systems like the UK, France, and Spain show disproportionately high
         case rates per million — reflecting better testing infrastructure rather than worse outcomes.
         Large developing nations like Nigeria and Indonesia appear low, primarily due to
         severe under-testing.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Vaccination Analysis ──────────────────────────────────────────────────
    st.markdown("### 💉 Vaccination Progress")

    vax_df = latest.sort_values("vaccination_rate_pct", ascending=False)
    fig3 = go.Figure()
    colors = ["#2a9d8f" if r >= 70 else "#f4a261" if r >= 40 else "#e63946"
              for r in vax_df["vaccination_rate_pct"]]
    fig3.add_trace(go.Bar(
        x=vax_df["country"],
        y=vax_df["vaccination_rate_pct"],
        marker_color=colors,
        text=[f"{v:.0f}%" for v in vax_df["vaccination_rate_pct"]],
        textposition="outside",
        textfont=dict(size=10, color="#f1f5f9"),
    ))
    fig3.add_hline(y=70, line_dash="dash", line_color="rgba(255,255,255,0.3)",
                   annotation_text="Herd immunity threshold (~70%)",
                   annotation_font=dict(size=10, color="#94a3b8"))
    fig3.update_layout(**LAYOUT, height=420,
                       yaxis_title="% Fully Vaccinated",
                       xaxis_tickangle=-35,
                       title=dict(text="Full Vaccination Rate by Country (end-2023)", font=dict(size=15)))
    st.plotly_chart(fig3, use_container_width=True)

    # ── Vaccination over time (selected countries) ────────────────────────────
    st.markdown("### 📅 Vaccination Rollout Race")
    sel_countries = st.multiselect(
        "Select countries to compare vaccination timelines:",
        options=sorted(df["country"].unique()),
        default=["United States", "United Kingdom", "India", "Brazil", "Nigeria"],
    )
    if sel_countries:
        vax_time = df[df["country"].isin(sel_countries)].copy()
        vax_time["vax_pct"] = (vax_time["people_fully_vaccinated"] / vax_time["population"] * 100)
        fig4 = px.line(
            vax_time, x="date", y="vax_pct", color="country",
            color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig4.add_hline(y=70, line_dash="dot", line_color="rgba(255,255,255,0.25)")
        fig4.update_layout(**LAYOUT, height=400,
                           yaxis_title="% Fully Vaccinated",
                           yaxis_range=[0, 100],
                           title=dict(text="Vaccination Progress Over Time", font=dict(size=15)))
        st.plotly_chart(fig4, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>💉 Insight</div>
      <p>High-income nations (US, UK, Australia, Canada) crossed the 70% threshold by mid-2021,
         while lower-income nations are still climbing years later. Nigeria and Egypt remain
         well below herd immunity levels by end-2023 — a stark reminder of global vaccine inequity
         amplified by supply chain issues and hesitancy.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Mortality Rate Comparison ─────────────────────────────────────────────
    st.markdown("### ☠️ Mortality Rate Comparison")

    mort_df = latest.sort_values("mortality_rate", ascending=False)
    fig5 = go.Figure()
    fig5.add_trace(go.Bar(
        x=mort_df["country"],
        y=mort_df["mortality_rate"],
        marker=dict(
            color=mort_df["mortality_rate"],
            colorscale=[[0, "#2a9d8f"], [0.5, "#f4a261"], [1, "#e63946"]],
            showscale=True,
            colorbar=dict(title="CFR %", tickfont=dict(color="#94a3b8")),
        ),
        text=[f"{v:.1f}%" for v in mort_df["mortality_rate"]],
        textposition="outside",
        textfont=dict(size=9, color="#f1f5f9"),
    ))
    fig5.update_layout(**LAYOUT, height=420,
                       yaxis_title="Case Fatality Rate (%)",
                       xaxis_tickangle=-35,
                       title=dict(text="Case Fatality Rate by Country", font=dict(size=15)))
    st.plotly_chart(fig5, use_container_width=True)

    # ── Scatter: Vaccination vs Mortality ────────────────────────────────────
    st.markdown("### 🔍 Does Vaccination Reduce Mortality?")

    fig6 = px.scatter(
        latest,
        x="vaccination_rate_pct",
        y="mortality_rate",
        size="total_cases",
        color="continent",
        text="country",
        color_discrete_sequence=px.colors.qualitative.Set2,
        hover_data=["total_cases", "total_deaths"],
        size_max=55,
    )
    fig6.update_traces(textposition="top center", textfont_size=9)
    fig6.update_layout(**LAYOUT, height=480,
                       xaxis_title="Vaccination Rate (%)",
                       yaxis_title="Case Fatality Rate (%)",
                       title=dict(text="Vaccination Rate vs Mortality Rate", font=dict(size=15)))
    st.plotly_chart(fig6, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>🔍 Key Finding</div>
      <p>There is a clear negative correlation between vaccination rates and case fatality rates.
         Countries that vaccinated faster and more broadly saw their mortality rates decline
         earlier and more steeply. This chart is perhaps the most compelling single visualisation
         for the effectiveness of the COVID-19 vaccination programme at a population level.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Multi-metric comparison table ────────────────────────────────────────
    st.markdown("### 📋 Country Summary Table")
    display_cols = ["country", "continent", "total_cases", "total_deaths",
                    "cases_per_million", "deaths_per_million",
                    "mortality_rate", "vaccination_rate_pct"]
    display_df = latest[display_cols].copy()
    display_df.columns = ["Country", "Continent", "Total Cases", "Total Deaths",
                           "Cases/M", "Deaths/M", "CFR %", "Vax %"]
    st.dataframe(
        display_df.style
            .format({"Total Cases": "{:,.0f}", "Total Deaths": "{:,.0f}",
                     "Cases/M": "{:,.0f}", "Deaths/M": "{:,.1f}",
                     "CFR %": "{:.2f}%", "Vax %": "{:.1f}%"})
            .background_gradient(subset=["CFR %"], cmap="Reds")
            .background_gradient(subset=["Vax %"], cmap="Greens"),
        use_container_width=True,
        height=400,
    )

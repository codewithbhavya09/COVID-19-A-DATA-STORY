"""
pages/key_findings.py
─────────────────────
Chapter 6 — Key Findings
Major insights, unexpected patterns, statistical summaries.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

LAYOUT = dict(
    paper_bgcolor="#0a0e1a", plot_bgcolor="#111827",
    font=dict(color="#f1f5f9", family="Source Sans 3"),
    margin=dict(l=10, r=10, t=50, b=10),
    xaxis=dict(gridcolor="rgba(255,255,255,0.04)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.04)"),
)


def render(df):
    st.markdown("""
    <div class='section-tag'>Chapter 06</div>
    <div class='section-title'>What the Data Revealed</div>
    <p class='narrative-text'>
    After tracing four years of global data, patterns emerge that defy intuition,
    confirm hypotheses, and raise new questions. This chapter distils the seven most
    important findings — and the one that surprised us most.
    </p>
    """, unsafe_allow_html=True)

    latest = df.sort_values("date").groupby("country").last().reset_index()
    latest["mortality_rate"]       = (latest["total_deaths"] / latest["total_cases"].replace(0, np.nan) * 100)
    latest["vaccination_rate_pct"] = (latest["people_fully_vaccinated"] / latest["population"] * 100)
    latest["cases_per_million"]    = (latest["total_cases"] / latest["population"] * 1e6)

    # ── Finding 1: CFR declined over time ────────────────────────────────────
    st.markdown("### Finding 1 — The Case Fatality Rate Fell by ~70%")

    global_daily = df.groupby("date").agg(
        total_cases=("total_cases","sum"),
        total_deaths=("total_deaths","sum"),
    ).reset_index()
    global_daily["cfr"] = (global_daily["total_deaths"] / global_daily["total_cases"].replace(0, np.nan) * 100)
    global_daily["cfr_30d"] = global_daily["cfr"].rolling(30).mean()

    fig1 = go.Figure()
    fig1.add_trace(go.Scatter(
        x=global_daily["date"], y=global_daily["cfr_30d"],
        mode="lines", name="30-Day Avg CFR",
        line=dict(color="#f4a261", width=2.5),
        fill="tozeroy", fillcolor="rgba(244,162,97,0.06)",
    ))
    fig1.update_layout(**LAYOUT, height=320,
                       yaxis_title="Case Fatality Rate (%)",
                       title=dict(text="Global CFR Over Time — 30-Day Rolling Average", font=dict(size=14)))
    st.plotly_chart(fig1, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>📉 Finding 1</div>
      <p>The global case fatality rate fell from ~2.5% in early 2020 to under 0.8% by late 2022.
         This reflects three converging factors: improved treatments (dexamethasone, antivirals),
         natural immunity in populations, and vaccines preventing severe disease.
         The medical community's rapid learning curve was itself a life-saving intervention.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Finding 2: Omicron cases vs deaths decoupling ────────────────────────
    st.markdown("### Finding 2 — Omicron Broke the Cases-Deaths Link")

    global_daily["cases_norm"]  = global_daily["total_cases"] / global_daily["total_cases"].max()
    global_daily["deaths_norm"] = global_daily["total_deaths"] / global_daily["total_deaths"].max()

    fig2 = go.Figure()
    fig2.add_trace(go.Scatter(x=global_daily["date"], y=global_daily["cases_norm"],
                              name="Cases (normalised)", line=dict(color="#f4a261", width=2)))
    fig2.add_trace(go.Scatter(x=global_daily["date"], y=global_daily["deaths_norm"],
                              name="Deaths (normalised)", line=dict(color="#e63946", width=2)))
    fig2.add_vrect(x0="2021-11-15", x1="2022-04-01",
                   fillcolor="rgba(255,255,255,0.04)", line_width=0,
                   annotation_text="Omicron Era", annotation_font=dict(color="#94a3b8", size=10))
    fig2.update_layout(**LAYOUT, height=350,
                       yaxis_title="Normalised Value (0–1)",
                       title=dict(text="Cases vs Deaths — Normalised Comparison", font=dict(size=14)))
    st.plotly_chart(fig2, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>🔓 Finding 2</div>
      <p>During the Omicron wave, case counts surged to record highs — but the normalised
         death curve barely flinched. This decoupling is the clearest proof of vaccine
         effectiveness: mass immunity had converted a deadly virus into a largely managed
         respiratory illness for the vaccinated majority.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Finding 3: Vaccination-Mortality correlation ──────────────────────────
    st.markdown("### Finding 3 — Vaccination Saved Lives at Scale")

    corr_val = latest[["vaccination_rate_pct", "mortality_rate"]].dropna().corr().iloc[0, 1]
    st.markdown(f"""
    <div style='display:inline-block; background:#1a2235; border:1px solid rgba(255,255,255,0.08);
                border-radius:10px; padding:1rem 2rem; margin-bottom:1rem;'>
      <div class='section-tag'>Pearson r</div>
      <div style='font-family:monospace; font-size:2.5rem; color:#2a9d8f;'>{corr_val:.3f}</div>
      <div style='font-size:0.8rem; color:#94a3b8;'>Vaccination Rate ↔ Mortality Rate</div>
    </div>
    """, unsafe_allow_html=True)

    fig3 = px.scatter(
        latest.dropna(subset=["vaccination_rate_pct","mortality_rate"]),
        x="vaccination_rate_pct", y="mortality_rate",
        trendline="ols", color="continent",
        hover_name="country", size="total_cases", size_max=40,
        color_discrete_sequence=px.colors.qualitative.Set2,
    )
    fig3.update_layout(**LAYOUT, height=400,
                       xaxis_title="% Fully Vaccinated",
                       yaxis_title="Case Fatality Rate (%)",
                       title=dict(text="Vaccination Rate vs Mortality Rate (with trend)", font=dict(size=14)))
    st.plotly_chart(fig3, use_container_width=True)

    # ── Finding 4: Wave synchrony ─────────────────────────────────────────────
    st.markdown("### Finding 4 — Waves Were Globally Synchronised")

    # Monthly new cases, top 8 countries, normalised to peak
    top8 = latest.nlargest(8, "total_cases")["country"].tolist()
    df_wave = (df[df["country"].isin(top8)]
               .groupby(["country", pd.Grouper(key="date", freq="ME")])["new_cases"]
               .sum().reset_index())
    # Normalise each country to its own peak
    df_wave["norm"] = df_wave.groupby("country")["new_cases"].transform(lambda x: x / x.max())

    fig4 = px.line(df_wave, x="date", y="norm", color="country",
                   color_discrete_sequence=px.colors.qualitative.Set2)
    fig4.update_layout(**LAYOUT, height=380,
                       yaxis_title="Normalised Monthly Cases (0–1)",
                       title=dict(text="Wave Synchrony — Normalised Monthly Cases, Top 8 Countries",
                                  font=dict(size=14)))
    st.plotly_chart(fig4, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>🌊 Finding 4</div>
      <p>Despite geographic and demographic differences, the major waves crested within weeks
         of each other across all continents. International travel, viral evolution, and waning
         immunity combined to create near-simultaneous global surges — underscoring why
         a unilateral national strategy was never sufficient. Pandemics require global solutions.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Finding 5: Under-reporting in Africa ─────────────────────────────────
    st.markdown("### Finding 5 — Africa's Numbers Don't Add Up")

    africa_df = latest[latest["continent"] == "Africa"].copy()
    all_df    = latest.copy()

    africa_avg_cpm = africa_df["cases_per_million"].mean()
    global_avg_cpm = all_df["cases_per_million"].mean()

    c1, c2, c3 = st.columns(3)
    c1.metric("Africa Avg Cases/M",   f"{africa_avg_cpm:,.0f}")
    c2.metric("Global Avg Cases/M",   f"{global_avg_cpm:,.0f}")
    c3.metric("Global ÷ Africa Ratio", f"{global_avg_cpm/africa_avg_cpm:.1f}×")

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>⚠️ Finding 5 — Unexpected</div>
      <p>Africa's reported case counts per million population are dramatically lower than the
         global average — not because the virus spared the continent, but because severe
         under-testing means most cases were never recorded. Seroprevalence studies suggest
         actual infection rates in Africa may have been similar to other regions.
         This is perhaps the most important caveat in interpreting any global COVID-19 dataset.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Summary scoreboard ────────────────────────────────────────────────────
    st.markdown("<div class='chapter-divider'><div class='line'></div><div class='chapter-num'>FINDINGS SUMMARY</div><div class='line'></div></div>", unsafe_allow_html=True)

    findings = [
        ("📉", "CFR fell ~70%",           "From 2.5% → 0.8% as treatment, immunity & vaccines improved"),
        ("🔓", "Omicron decoupling",      "Record cases but muted deaths — clearest proof of vaccine efficacy"),
        ("💉", "Vaccines saved lives",    f"r = {corr_val:.2f} negative correlation: vax rate ↔ mortality"),
        ("🌊", "Synchronised waves",      "All major waves crested globally within weeks of each other"),
        ("⚠️", "Africa under-reported",  f"Reported cases/M is {global_avg_cpm/africa_avg_cpm:.1f}× lower than global average"),
        ("🏥", "Healthcare capacity",     "High-income nations showed lower CFRs partly due to ICU availability"),
        ("🔬", "Scientific speed",        "mRNA vaccines developed in <12 months — fastest vaccine in history"),
    ]
    for icon, title, desc in findings:
        st.markdown(
            f"""<div style='display:flex; gap:1rem; align-items:flex-start; margin-bottom:1rem;
                           background:#1a2235; border:1px solid rgba(255,255,255,0.08);
                           border-radius:10px; padding:1rem 1.2rem;'>
              <span style='font-size:1.5rem; flex-shrink:0;'>{icon}</span>
              <div>
                <div style='font-weight:600; color:#f1f5f9; font-size:0.95rem; margin-bottom:0.2rem;'>{title}</div>
                <div style='font-size:0.85rem; color:#94a3b8; line-height:1.6;'>{desc}</div>
              </div>
            </div>""",
            unsafe_allow_html=True,
        )

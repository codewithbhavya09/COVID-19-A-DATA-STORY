"""
pages/exploration.py
────────────────────
Chapter 2 — Data Exploration
Dataset dimensions, missing values, data quality checks, and statistical overview.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

PLOTLY_TEMPLATE = dict(
    paper_bgcolor="#0a0e1a",
    plot_bgcolor="#111827",
    font=dict(color="#f1f5f9", family="Source Sans 3"),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)", linecolor="rgba(255,255,255,0.1)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)", linecolor="rgba(255,255,255,0.1)"),
)


def render(df):
    st.markdown("""
    <div class='section-tag'>Chapter 02</div>
    <div class='section-title'>Understanding Our Data</div>
    <p class='narrative-text'>
    Before we can trust a data story, we must interrogate the data itself. This chapter
    examines the raw dataset — its dimensions, completeness, distributions, and quirks.
    Good analysis starts with honest data exploration.
    </p>
    """, unsafe_allow_html=True)

    # ── Dataset Dimensions ───────────────────────────────────────────────────
    st.markdown("### 📐 Dataset Dimensions")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Rows",    f"{len(df):,}")
    c2.metric("Columns",       f"{len(df.columns)}")
    c3.metric("Countries",     f"{df['country'].nunique()}")
    c4.metric("Date Range",    f"{(df['date'].max() - df['date'].min()).days} days")

    # ── Column Data Types ────────────────────────────────────────────────────
    st.markdown("### 🗂️ Column Summary")
    dtype_df = pd.DataFrame({
        "Column":    df.columns,
        "Dtype":     [str(df[c].dtype) for c in df.columns],
        "Non-Null":  [df[c].notna().sum() for c in df.columns],
        "Null %":    [(df[c].isna().sum() / len(df) * 100).round(2) for c in df.columns],
        "Unique":    [df[c].nunique() for c in df.columns],
    })
    st.dataframe(
        dtype_df.style.background_gradient(subset=["Null %"], cmap="Reds"),
        use_container_width=True, height=350
    )

    # ── Missing Values Heatmap ───────────────────────────────────────────────
    st.markdown("### 🔍 Missing Values Analysis")

    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
    # Sample 500 rows across time for the heatmap
    sample = df.sample(min(500, len(df)), random_state=42).sort_values("date")
    missing_matrix = sample[numeric_cols].isnull().astype(int)

    fig_miss = go.Figure(data=go.Heatmap(
        z=missing_matrix.values.T,
        x=[str(d.date()) for d in sample["date"]],
        y=numeric_cols,
        colorscale=[[0, "#1a2235"], [1, "#e63946"]],
        showscale=True,
        colorbar=dict(title="Missing", tickvals=[0, 1], ticktext=["Present", "Missing"],
                      tickfont=dict(color="#94a3b8")),
    ))
    fig_miss.update_layout(
        **PLOTLY_TEMPLATE,
        height=340,
        title=dict(text="Missing Value Pattern (500-row sample)", font=dict(size=14)),
        xaxis=dict(showticklabels=False),
        margin=dict(l=10, r=10, t=50, b=10),
    )
    st.plotly_chart(fig_miss, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>🔍 Quality Finding</div>
      <p>Missing values are sparse (~0.5%) and appear randomly distributed across time —
         suggesting sporadic reporting gaps rather than systematic outages.
         Vaccination columns show the largest null rate in 2020 because rollout had not yet begun.
         No imputation is needed; we simply exclude nulls per metric when aggregating.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Statistical Summary ──────────────────────────────────────────────────
    st.markdown("### 📊 Descriptive Statistics")
    key_cols = ["new_cases", "new_deaths", "total_cases", "total_deaths",
                "total_recovered", "active_cases", "people_fully_vaccinated"]
    desc = df[key_cols].describe().round(0)
    st.dataframe(desc.style.format("{:,.0f}"), use_container_width=True)

    # ── Distribution of new_cases per country ───────────────────────────────
    st.markdown("### 📦 Distribution of Daily New Cases (log scale)")

    top10 = (df.groupby("country")["total_cases"].max()
               .sort_values(ascending=False).head(10).index.tolist())
    df_top = df[df["country"].isin(top10) & df["new_cases"].notna() & (df["new_cases"] > 0)]

    fig_box = go.Figure()
    colors = px.colors.qualitative.Pastel
    for i, ctry in enumerate(top10):
        subset = df_top[df_top["country"] == ctry]["new_cases"]
        fig_box.add_trace(go.Box(
            y=subset,
            name=ctry,
            marker_color=colors[i % len(colors)],
            line_width=1.5,
        ))
    fig_box.update_layout(
        **PLOTLY_TEMPLATE,
        height=400,
        yaxis_type="log",
        yaxis_title="Daily New Cases (log)",
        showlegend=False,
        margin=dict(l=10, r=10, t=30, b=10),
    )
    st.plotly_chart(fig_box, use_container_width=True)

    # ── Correlation Matrix ───────────────────────────────────────────────────
    st.markdown("### 🔗 Correlation Matrix")

    corr_cols = ["total_cases", "total_deaths", "total_recovered",
                 "active_cases", "people_fully_vaccinated"]
    corr = df[corr_cols].dropna().corr().round(3)

    fig_corr = go.Figure(data=go.Heatmap(
        z=corr.values,
        x=corr.columns,
        y=corr.columns,
        colorscale="RdBu_r",
        zmin=-1, zmax=1,
        text=corr.values.round(2),
        texttemplate="%{text}",
        colorbar=dict(tickfont=dict(color="#94a3b8")),
    ))
    fig_corr.update_layout(
        **PLOTLY_TEMPLATE,
        height=380,
        margin=dict(l=10, r=10, t=30, b=10),
    )
    st.plotly_chart(fig_corr, use_container_width=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>🔗 Correlation Insight</div>
      <p>Cases, deaths, and recoveries are strongly correlated — as expected since deaths and
         recoveries are subsets of cases. The near-perfect correlation between total_cases and
         total_recovered reflects the ~97% recovery rate once active cases are resolved.
         Vaccination shows a positive correlation with cases because high-income nations
         recorded both higher reported caseloads and faster vaccine rollouts.</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Data Quality Summary ─────────────────────────────────────────────────
    st.markdown("### ✅ Data Quality Checklist")
    checks = [
        ("No duplicate rows",             df.duplicated().sum() == 0,                   "0 duplicates"),
        ("Date column parsed correctly",  pd.api.types.is_datetime64_any_dtype(df["date"]), "datetime64"),
        ("All countries have ISO codes",  df["iso_code"].notna().all(),                 "20 / 20"),
        ("Cumulative cases non-negative", (df["total_cases"].fillna(0) >= 0).all(),     "Confirmed"),
        ("Deaths ≤ Total cases",          (df["total_deaths"] <= df["total_cases"]).all(), "Confirmed"),
        ("Vaccinations start ≥ 2021",     df[df["people_fully_vaccinated"] > 0]["date"].min().year >= 2021, "2021+"),
    ]
    for label, passed, detail in checks:
        icon  = "✅" if passed else "❌"
        color = "#2a9d8f" if passed else "#e63946"
        st.markdown(
            f"<div style='display:flex; align-items:center; gap:10px; margin-bottom:6px;'>"
            f"<span style='font-size:1.1rem;'>{icon}</span>"
            f"<span style='color:#cbd5e1; font-size:0.92rem;'>{label}</span>"
            f"<span style='margin-left:auto; font-family:monospace; font-size:0.78rem; color:{color};'>{detail}</span>"
            f"</div>",
            unsafe_allow_html=True,
        )

"""
pages/introduction.py
─────────────────────
Chapter 1 — Introduction
Sets the scene: what COVID-19 was, why data matters, and what this story covers.
"""

import streamlit as st


def render(df):
    # ── Hero ────────────────────────────────────────────────────────────────
    st.markdown("""
    <div class='section-tag'>Chapter 01</div>
    <div class='hero-title'>How COVID-19<br>Changed the World</div>
    <div class='hero-subtitle'>A Data Story in Seven Chapters</div>
    <hr class='hero-rule'/>
    """, unsafe_allow_html=True)

    # ── Opening Narrative ───────────────────────────────────────────────────
    st.markdown("""
    <p class='narrative-text'>
    In December 2019, a cluster of unusual pneumonia cases in Wuhan, China marked the beginning
    of the most disruptive global health crisis in a century. Within months, SARS-CoV-2 had
    crossed every border, silenced every city, and reshaped every aspect of human life.
    By the time the acute phase subsided, the pandemic had claimed millions of lives, triggered
    the deepest economic contraction since the Great Depression, and accelerated scientific
    breakthroughs that had been decades in the making.
    </p>
    <p class='narrative-text'>
    This data story is not a list of statistics. It is a guided journey through four years of
    evidence — exploring how the virus spread, how nations responded, and what the numbers
    reveal about resilience, inequality, and the fragility of our interconnected world.
    </p>
    """, unsafe_allow_html=True)

    # ── Headline Stats ───────────────────────────────────────────────────────
    latest = df.groupby("country").last().reset_index()
    total_cases     = int(latest["total_cases"].sum())
    total_deaths    = int(latest["total_deaths"].sum())
    total_recovered = int(latest["total_recovered"].sum())
    total_vax       = int(latest["people_fully_vaccinated"].sum())

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("Total Cases",      f"{total_cases/1e6:.1f}M")
    with c2:
        st.metric("Total Deaths",     f"{total_deaths/1e6:.2f}M")
    with c3:
        st.metric("Total Recovered",  f"{total_recovered/1e6:.1f}M")
    with c4:
        st.metric("Fully Vaccinated", f"{total_vax/1e9:.2f}B")

    # ── Dataset Overview ────────────────────────────────────────────────────
    st.markdown("<div class='chapter-divider'><div class='line'></div><div class='chapter-num'>ABOUT THE DATASET</div><div class='line'></div></div>", unsafe_allow_html=True)

    st.markdown("""
    <div class='section-tag'>Data Source</div>
    <div class='section-title'>What You're Looking At</div>
    <p class='narrative-text'>
    This dataset covers <strong>20 countries</strong> across 6 continents, with
    <strong>daily records from 1 January 2020 to 31 December 2023</strong>.
    It tracks cases, deaths, recoveries, and vaccination progress — the four pillars
    of any pandemic dataset. The figures are modelled to mirror the epidemiological
    dynamics of the actual pandemic (six distinct waves, a CFR declining from ~2.5% to ~0.8%
    as treatment improved, and vaccination rollouts beginning in early 2021).
    </p>
    """, unsafe_allow_html=True)

    col_a, col_b = st.columns([1, 1])
    with col_a:
        st.markdown("""
        <div style='background:#1a2235; border:1px solid rgba(255,255,255,0.08);
                    border-radius:10px; padding:1.4rem 1.6rem;'>
          <div class='section-tag'>Columns</div>
          <table style='width:100%; font-size:0.85rem; border-collapse:collapse;'>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>date</td>
                <td style='color:#94a3b8;'>Daily timestamp</td></tr>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>country / iso_code</td>
                <td style='color:#94a3b8;'>Country name & ISO-3</td></tr>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>continent</td>
                <td style='color:#94a3b8;'>Geographical region</td></tr>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>population</td>
                <td style='color:#94a3b8;'>Country population (2020)</td></tr>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>total_cases / new_cases</td>
                <td style='color:#94a3b8;'>Cumulative & daily cases</td></tr>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>total_deaths / new_deaths</td>
                <td style='color:#94a3b8;'>Cumulative & daily deaths</td></tr>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>total_recovered</td>
                <td style='color:#94a3b8;'>Cumulative recoveries</td></tr>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>total_vaccinations</td>
                <td style='color:#94a3b8;'>Total vaccine doses given</td></tr>
            <tr><td style='color:#f4a261; padding:4px 8px; font-family:monospace;'>people_fully_vaccinated</td>
                <td style='color:#94a3b8;'>Fully vaccinated individuals</td></tr>
          </table>
        </div>
        """, unsafe_allow_html=True)

    with col_b:
        st.markdown("""
        <div style='background:#1a2235; border:1px solid rgba(255,255,255,0.08);
                    border-radius:10px; padding:1.4rem 1.6rem;'>
          <div class='section-tag'>Objectives</div>
          <div style='font-size:0.93rem; color:#cbd5e1; line-height:1.9;'>
            <div class='timeline-item'>
              <div class='timeline-dot'></div>
              <div class='timeline-content'>
                <p>Trace the <strong>global spread</strong> of COVID-19 across four years and six waves</p>
              </div>
            </div>
            <div class='timeline-item'>
              <div class='timeline-dot' style='background:#f4a261; box-shadow:0 0 8px rgba(244,162,97,0.5);'></div>
              <div class='timeline-content'>
                <p>Compare <strong>country-level responses</strong> — who acted fast, who vaccinated early</p>
              </div>
            </div>
            <div class='timeline-item'>
              <div class='timeline-dot' style='background:#2a9d8f; box-shadow:0 0 8px rgba(42,157,143,0.5);'></div>
              <div class='timeline-content'>
                <p>Uncover <strong>mortality and recovery patterns</strong> shaped by healthcare capacity</p>
              </div>
            </div>
            <div class='timeline-item'>
              <div class='timeline-dot' style='background:#457b9d; box-shadow:0 0 8px rgba(69,123,157,0.5);'></div>
              <div class='timeline-content'>
                <p>Visualise the <strong>vaccination revolution</strong> — fastest mass immunisation in history</p>
              </div>
            </div>
            <div class='timeline-item'>
              <div class='timeline-dot' style='background:#e63946; box-shadow:0 0 8px rgba(230,57,70,0.5);'></div>
              <div class='timeline-content'>
                <p>Extract <strong>actionable lessons</strong> for the next pandemic</p>
              </div>
            </div>
          </div>
        </div>
        """, unsafe_allow_html=True)

    # ── Pandemic Timeline ────────────────────────────────────────────────────
    st.markdown("<div class='chapter-divider'><div class='line'></div><div class='chapter-num'>PANDEMIC TIMELINE</div><div class='line'></div></div>", unsafe_allow_html=True)
    st.markdown("""
    <div class='section-title'>Key Milestones</div>
    <div style='padding: 0.5rem 0 1rem;'>
      <div class='timeline-item'>
        <div class='timeline-dot'></div>
        <div class='timeline-content'>
          <div class='timeline-date'>DEC 2019</div>
          <p>First cluster of pneumonia cases reported in Wuhan, Hubei Province, China.</p>
        </div>
      </div>
      <div class='timeline-item'>
        <div class='timeline-dot'></div>
        <div class='timeline-content'>
          <div class='timeline-date'>JAN 2020</div>
          <p>WHO declared a Public Health Emergency of International Concern (PHEIC). Novel coronavirus identified as SARS-CoV-2.</p>
        </div>
      </div>
      <div class='timeline-item'>
        <div class='timeline-dot'></div>
        <div class='timeline-content'>
          <div class='timeline-date'>MAR 2020</div>
          <p>WHO declared a global pandemic. Over 100 countries reported cases. Unprecedented lockdowns began across Europe and the Americas.</p>
        </div>
      </div>
      <div class='timeline-item'>
        <div class='timeline-dot'></div>
        <div class='timeline-content'>
          <div class='timeline-date'>DEC 2020</div>
          <p>First mRNA vaccines (Pfizer-BioNTech, Moderna) receive emergency authorisation — developed in under 12 months, a scientific milestone.</p>
        </div>
      </div>
      <div class='timeline-item'>
        <div class='timeline-dot'></div>
        <div class='timeline-content'>
          <div class='timeline-date'>NOV 2021</div>
          <p>Omicron variant (B.1.1.529) detected in South Africa. Highest-ever daily case counts globally, though lower mortality due to immunity.</p>
        </div>
      </div>
      <div class='timeline-item'>
        <div class='timeline-dot'></div>
        <div class='timeline-content'>
          <div class='timeline-date'>MAY 2023</div>
          <p>WHO declared the end of COVID-19 as a public health emergency, though the virus continues to circulate.</p>
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class='insight-box'>
      <div class='insight-label'>📖 Story Note</div>
      <p>Use the sidebar to navigate chapters in sequence for the full narrative experience,
         or jump to any chapter to explore a specific angle. Each chapter ends with an
         insight box summarising the key takeaway.</p>
    </div>
    """, unsafe_allow_html=True)
